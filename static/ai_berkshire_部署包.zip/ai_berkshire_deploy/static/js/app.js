// AI Berkshire Web - Application Logic
let currentSkill = null;
let allSkills = [];
let currentReport = '';
let ws = null;
let _researchAbort = null;   // AbortController for batch mode
let _historyData = [];       // Cached history for search
let _wsReconnectAttempts = 0;
let _wsShouldReconnect = false;
const _WS_MAX_RECONNECT = 3;
const _WS_RECONNECT_DELAYS = [2000, 5000, 10000]; // ms

let currentTaskId = null;    // task_id reported by server (for real cancel)
let _agentStreamBuffers = {}; // per-agent stream buffers (event protocol v2)
let _userCancelled = false;  // distinguish user cancel from timeout abort
let _progressTimer = null;   // elapsed-time ticker
let _progressStartTs = 0;
let _renderScheduled = false; // streaming render throttle flag
let _favorites = new Set();  // starred skills
let _compareSelection = new Set(); // history compare checkboxes

// Category icons
const CAT_ICONS = {
  '深度研究': 'K',
  '财报分析': 'E',
  '行业筛选': 'I',
  '持仓管理': 'P',
  '思维工具': 'T',
  '日报': 'D'
};

// ==================== Helpers ====================
function escHtml(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function fmtDuration(sec) {
  sec = Math.round(sec || 0);
  if (sec < 60) return sec + '秒';
  var m = Math.floor(sec / 60), s = sec % 60;
  return m + '分' + (s ? s + '秒' : '');
}

function fmtTokens(t) {
  if (!t || !t.total_tokens) return '';
  var n = t.total_tokens;
  var s = n >= 10000 ? (n / 10000).toFixed(1) + '万' : String(n);
  return '约 ' + s + ' tokens';
}

function skillDisplayName(name) {
  var s = allSkills.find(function(x) { return x.name === name; });
  return s ? (s.display_name || s.name) : name;
}

// ==================== Toast ====================
function showToast(msg, type) {
  type = type || 'info';
  var c = document.getElementById('toast-container');
  var el = document.createElement('div');
  el.className = 'toast-msg ' + type;
  el.textContent = msg;
  c.appendChild(el);
  setTimeout(function() {
    el.classList.add('out');
    setTimeout(function() { el.remove(); }, 300);
  }, 3000);
}

// ==================== Init ====================

function _promptForToken(callback) {
  var secret = prompt('请输入访问令牌（服务器 BERKSHIRE_API_TOKEN）：');
  if (!secret) { document.body.innerHTML = '<div style="padding:40px;text-align:center;color:#c4a77d">需要令牌才能访问</div>'; return; }
  loginWithToken(secret).then(function(data) {
    if (data && data.note === 'Auth disabled') {
      localStorage.setItem('ai_berkshire_jwt', 'disabled');
    }
    callback();
  }).catch(function(e) {
    alert('令牌无效：' + e.message);
    _promptForToken(callback);
  });
}
document.addEventListener('DOMContentLoaded', function() {
  // Restore favorites
  try {
    _favorites = new Set(JSON.parse(localStorage.getItem('ai_berkshire_favs') || '[]'));
  } catch(e) { _favorites = new Set(); }

  // Restore failed tasks
  renderFailedTasks();
  updateUploadVisibility();

  // Restore last report from sessionStorage (only if model is configured)
  try {
    var savedReport = sessionStorage.getItem('ai_berkshire_report');
    var savedMeta = JSON.parse(sessionStorage.getItem('ai_berkshire_report_meta') || '{}');
    var _cfgCheck = _loadLlmConfig();
    var _hasCfg = !!(_cfgCheck && (_cfgCheck.model || _cfgCheck.api_key || _cfgCheck.base_url));
    if (savedReport && _hasCfg) {
      currentReport = savedReport;
      document.getElementById('empty-state').style.display = 'none';
      document.getElementById('result-area').style.display = 'block';
      renderReport(savedReport);
      // Banner: make clear this is a restored report, not a fresh one
      var banner = document.getElementById('restore-banner');
      var when = savedMeta.ts ? new Date(savedMeta.ts).toLocaleString() : '未知时间';
      var skillText = savedMeta.skill ? skillDisplayName(savedMeta.skill) : '未知技能';
      document.getElementById('restore-banner-text').textContent =
        '这是上次会话恢复的报告（' + skillText + ' · ' + when + '），并非刚刚生成';
      banner.style.display = 'flex';
    }
  } catch(e) {}

  // Enter key to submit
  document.getElementById('arg-field').addEventListener('keydown', function(e) {
    if (e.key === 'Enter') startResearch();
  });

  // Input char count & hint
  document.getElementById('arg-field').addEventListener('input', function(e) {
    var val = e.target.value;
    var cc = document.getElementById('charCount');
    if (val.length > 0) {
      cc.textContent = val.length + '字';
      var isCode = /^\d{6}$/.test(val);
      document.getElementById('input-hint').textContent = isCode ? '检测到股票代码格式' : (currentSkill ? currentSkill.input_hint || '' : '');
    } else {
      cc.textContent = '';
      document.getElementById('input-hint').textContent = currentSkill ? currentSkill.input_hint || '' : '';
    }
  });

  renderArgHistory();

  // Fetch server model info (supported model list, default model)
  fetch('/api/llm/default').then(function(r) { return r.json(); })
    .then(function(d) { _initLlmDefaults(d); })
    .catch(function() { _initLlmDefaults(null); });
  loadSkills();
});

function dismissRestoreBanner() {
  document.getElementById('restore-banner').style.display = 'none';
}

// ==================== Sidebar (mobile) ====================
function toggleSidebar() {
  document.body.classList.toggle('sidebar-open');
}

// ==================== Skills ====================
async function loadSkills() {
  try {
    var res = await fetch('/api/skills', { headers: getAuthHeaders() });
    if (res.status === 401) {
      // Token expired or server restarted with a new secret — re-login
      localStorage.removeItem('ai_berkshire_jwt');
      location.reload();
      return;
    }
    var data = await res.json();
    allSkills = data.skills;
    document.getElementById('nav-loading').style.display = 'none';
    renderSkillNav(allSkills);
    if (!prefillFromURL()) {
      var saved = localStorage.getItem('ai_berkshire_skill');
      if (saved) selectSkill(saved);
      else if (allSkills.length > 0) selectSkill(allSkills[0].name);
    }
  } catch (e) {
    document.getElementById('nav-loading').innerHTML =
      '<p style="color:var(--accent-red);padding:12px 20px;font-size:0.8rem">技能加载失败 <button onclick="location.reload()" style="cursor:pointer;background:#30363d;color:#e6edf3;border:1px solid #484f58;border-radius:4px;padding:2px 10px;margin-left:8px">重试</button></p>';
    console.error('Failed to load skills:', e);
    setTimeout(function() {
      var params = new URLSearchParams(window.location.search);
      var skill = params.get('skill') || '';
      var args = params.get('arguments') || params.get('company') || '';
      if (skill && args) {
        document.getElementById('arg-field').value = args;
        document.getElementById('skill-name').textContent = skill;
        if (params.get('auto') !== '0' && params.get('noauto') !== '1') {
          setTimeout(function() {
            try { startResearch(); } catch(e2) { console.error('auto-start failed:', e2); }
          }, 1000);
        }
      }
    }, 500);
  }
}

// Build nav sections dynamically from API categories — new categories
// (e.g. 日报) appear automatically without touching the HTML.
function renderSkillNav(skills) {
  var nav = document.getElementById('nav-categories');
  var cats = [];
  var catMap = {};
  skills.forEach(function(s) {
    if (!catMap[s.category]) {
      catMap[s.category] = [];
      cats.push(s.category);
    }
    catMap[s.category].push(s);
  });

  var html = '';

  // Favorites pinned on top
  var favs = skills.filter(function(s) { return _favorites.has(s.name); });
  if (favs.length) {
    html += buildSection('⭐ 收藏', 'favorites', favs);
  }
  cats.forEach(function(cat) {
    html += buildSection(cat, cat, catMap[cat]);
  });
  nav.innerHTML = html;

  // Restore collapsed states
  try {
    var state = JSON.parse(localStorage.getItem('ai_berkshire_toggle') || '{}');
    nav.querySelectorAll('.nav-section').forEach(function(section) {
      var items = section.querySelector('.nav-items');
      var header = section.querySelector('.nav-header');
      var cat = items.id ? items.id.replace('cat-', '') : '';
      if (state[cat]) {
        header.classList.add('collapsed');
        items.classList.add('collapsed');
      }
    });
  } catch(e) {}

  filterSkills();
}

function buildSection(label, key, skills) {
  var items = skills.map(function(s) {
    var badge = s.is_multi_agent ? '<span class="multi-badge">' + s.agent_count + 'A</span>' : '';
    var star = '<span class="fav-star' + (_favorites.has(s.name) ? ' on' : '') +
      '" data-star="' + escHtml(s.name) + '" onclick="toggleFav(event,\'' + escHtml(s.name) + '\')">★</span>';
    return '<div class="nav-item" data-skill="' + escHtml(s.name) + '" onclick="selectSkill(\'' + escHtml(s.name) + '\')" title="' + escHtml(s.description || '') + '">' +
      '<span class="nav-item-name">' + escHtml(s.display_name || s.name) + badge + '</span>' + star + '</div>';
  }).join('');
  return '<div class="nav-section">' +
    '<div class="nav-header" onclick="toggleSection(this)"><span>' + escHtml(label) + '</span><span class="arrow">V</span></div>' +
    '<div class="nav-items" id="cat-' + escHtml(key) + '" data-cat="' + escHtml(label) + '">' + items + '</div></div>';
}

function toggleFav(e, name) {
  e.stopPropagation();
  if (_favorites.has(name)) _favorites.delete(name);
  else _favorites.add(name);
  localStorage.setItem('ai_berkshire_favs', JSON.stringify(Array.from(_favorites)));
  // Re-render nav but keep the active skill highlighted
  var active = currentSkill ? currentSkill.name : null;
  renderSkillNav(allSkills);
  if (active) {
    document.querySelectorAll('.nav-item[data-skill="' + active + '"]')
      .forEach(function(el) { el.classList.add('active'); });
  }
}

function filterSkills() {
  var q = (document.getElementById('skill-search').value || '').trim().toLowerCase();
  document.querySelectorAll('#nav-categories .nav-section').forEach(function(section) {
    var visible = 0;
    section.querySelectorAll('.nav-item').forEach(function(item) {
      var name = item.textContent.toLowerCase();
      var skill = allSkills.find(function(s) { return s.name === item.dataset.skill; });
      var hay = name + ' ' + (skill ? (skill.name + ' ' + (skill.description || '')).toLowerCase() : '');
      var show = !q || hay.indexOf(q) >= 0;
      item.style.display = show ? '' : 'none';
      if (show) visible++;
    });
    section.style.display = visible ? '' : 'none';
  });
}

function selectSkill(name) {
  var skill = allSkills.find(function(s) { return s.name === name; });
  if (!skill) return;

  currentSkill = skill;
  // Close history panel when switching skills
  document.getElementById('history-area').style.display = 'none';
  localStorage.setItem('ai_berkshire_skill', name);

  document.querySelectorAll('.nav-item').forEach(function(el) { el.classList.remove('active'); });
  document.querySelectorAll('.nav-item[data-skill="' + name + '"]')
    .forEach(function(el) { el.classList.add('active'); });

  document.getElementById('skill-name').textContent = skill.name;
  document.getElementById('skill-label').textContent = skill.display_name || '';
  document.getElementById('skill-icon').textContent = CAT_ICONS[skill.category] || '?';
  document.getElementById('skill-desc').textContent = skill.description || '';
  document.getElementById('input-hint').textContent = skill.input_hint || '';
  document.getElementById('arg-field').placeholder = skill.input_hint || '输入分析目标...';

  var btn = document.getElementById('btn-research');
  btn.textContent = skill.is_multi_agent ? '启动 ' + skill.agent_count + ' Agent 并行研究' : '开始研究';

  // On mobile, close the drawer after picking a skill
  if (window.innerWidth <= 860) document.body.classList.remove('sidebar-open');
}

// ==================== Sidebar Toggle ====================
function toggleSection(header) {
  header.classList.toggle('collapsed');
  var items = header.nextElementSibling;
  items.classList.toggle('collapsed');
  var cat = items.id ? items.id.replace('cat-', '') : '';
  if (cat) {
    var state = JSON.parse(localStorage.getItem('ai_berkshire_toggle') || '{}');
    state[cat] = header.classList.contains('collapsed');
    localStorage.setItem('ai_berkshire_toggle', JSON.stringify(state));
  }
}

function quickStart(skillName, args) {
  selectSkill(skillName);
  document.getElementById('arg-field').value = args;
  startResearch();
}

// ==================== LLM Config (per-user model selection) ====================
// Config lives only in the visitor's own browser (localStorage) and is sent
// with each research request — the server never persists anyone's API key.

// Per-provider model catalog.  Values pulled from /api/llm/default on page
// load so the server-owner can update the list without touching frontend code.
var LLM_PROVIDER_PRESETS = {
  deepseek: {
    label: 'DeepSeek',
    base_url: 'https://api.deepseek.com',
    models: []
  },
  openai: {
    label: 'OpenAI',
    base_url: 'https://api.openai.com/v1',
    models: ['gpt-4.1', 'gpt-4.1-mini', 'gpt-4o', 'gpt-4o-mini', 'o4-mini', 'o3']
  },
  codex: {
    label: 'Codex（OpenAI）',
    base_url: 'https://api.openai.com/v1',
    models: ['gpt-5.1-codex-max', 'gpt-5.1-codex', 'gpt-5-codex-mini', 'codex-2025-08-01']
  },
  anthropic: {
    label: 'Anthropic（Claude）',
    base_url: 'https://api.anthropic.com/v1',
    models: ['claude-opus-4-20250514', 'claude-sonnet-4-20250514', 'claude-3.5-sonnet', 'claude-3.5-haiku']
  },
  google: {
    label: 'Google（Gemini）',
    base_url: 'https://generativelanguage.googleapis.com/v1beta/openai',
    models: ['gemini-2.5-pro', 'gemini-2.5-flash', 'gemini-2.0-flash', 'gemini-2.0-flash-lite']
  },
  zhipu: {
    label: '智谱（GLM）',
    base_url: 'https://open.bigmodel.cn/api/paas/v4',
    models: ['glm-4.7', 'glm-4.7-flash', 'glm-4.5', 'glm-4v-plus', 'glm-4v-flash']
  },
  qwen: {
    label: '阿里（通义千问）',
    base_url: 'https://dashscope.aliyuncs.com/compatible-mode/v1',
    models: ['qwen3-max', 'qwen3-plus', 'qwen3-turbo', 'qwen-vl-max', 'qwen-vl-plus']
  },
  baidu: {
    label: '百度（文心）',
    base_url: 'https://qianfan.baidubce.com/v2',
    models: ['ernie-4.5-turbo', 'ernie-4.5', 'ernie-4.0-turbo', 'ernie-speed', 'ernie-lite']
  },
  hunyuan: {
    label: '腾讯混元',
    base_url: 'https://api.hunyuan.cloud.tencent.com/v1',
    models: ['hunyuan-turbos', 'hunyuan-t1', 'hunyuan-a13b', 'hunyuan-lite']
  },
  doubao: {
    label: '字节（豆包）',
    base_url: 'https://ark.cn-beijing.volces.com/api/v3',
    models: ['doubao-1.5-pro-256k', 'doubao-1.5-lite-128k', 'doubao-1.5-vision-pro']
  },
  kimi: {
    label: 'Kimi（Moonshot）',
    base_url: 'https://api.moonshot.cn/v1',
    models: ['kimi-k3', 'kimi-k3-0905-preview', 'kimi-k2-0905-preview']
  },
  ollama: {
    label: 'Ollama（本地）',
    base_url: 'http://localhost:11434/v1',
    models: ['qwen3:14b', 'qwen3:7b', 'llama4:8b', 'deepseek-r1:8b', 'gemma3:12b']
  },
  custom: {
    label: '自定义中转站',
    base_url: '',
    models: []
  }
};
var _serverDefaultModel = '';

// Agent name → human-readable label for per-agent model UI
var AGENT_LABELS = {
  'business-analyst': '商业模式分析师',
  'financial-analyst': '财务估值分析师',
  'industry-researcher': '行业竞争分析师',
  'risk-assessor': '风险评估师',
  'company-event-scout': '公司事件侦察员',
  'regulatory-watcher': '监管政策观察员',
  'industry-peer-analyst': '行业对手分析师',
  'sentiment-tracker': '市场情绪追踪员',
  'business-interpreter': '生意本质解读者',
  'financial-auditor': '财务质量审计师',
  'competition-analyst': '竞争变化解读者',
  'risk-hunter': '风险信号猎手',
  'editor': '公众号财经编辑',
  'reader-reviewer': '投资者评审',
  'researcher': '深度研究员'
};

function _getAgentLabel(name) {
  return AGENT_LABELS[name] || name;
}

// Called once on page load to pull the server's supported model list.
function _initLlmDefaults(serverInfo) {
  if (serverInfo && serverInfo.supported_models && serverInfo.supported_models.length) {
    LLM_PROVIDER_PRESETS.deepseek.models = serverInfo.supported_models;
  }
  _serverDefaultModel = (serverInfo && serverInfo.model) || '';
  updatePoweredBy();
}

function updatePoweredBy() {
  var el = document.getElementById('powered-by');
  var cfg = _loadLlmConfig();
  if (cfg && (cfg.model || cfg.base_url || cfg.api_key)) {
    var presetLabel = '';
    if (cfg._preset && LLM_PROVIDER_PRESETS[cfg._preset]) {
      presetLabel = LLM_PROVIDER_PRESETS[cfg._preset].label + ' · ';
    }
    el.textContent = '模型：' + presetLabel + (cfg.model || '自定义') + '（自定义）';
  } else if (cfg && cfg.agent_models && Object.keys(cfg.agent_models).length) {
    // Only per-agent configured — show first agent's model
    var agents = Object.keys(cfg.agent_models);
    var first = cfg.agent_models[agents[0]];
    var label = typeof first === 'string' ? first : (first.model || '自定义');
    var p = (typeof first === 'object' && first._provider) ? first._provider : '';
    el.textContent = '模型：' + (p ? p + ' · ' : '') + label + '（Agent）';
  } else {
    el.textContent = '模型：' + (_serverDefaultModel || 'DeepSeek');
  }
  updateLlmNotice();
}

// Red reminder for visitors who haven't configured their own provider/key.
// Shown until any provider config is saved; click opens the settings modal.
function updateLlmNotice() {
  var notice = document.getElementById('llm-notice');
  if (!notice) return;
  var cfg = _loadLlmConfig();
  var hasGlobal = !!(cfg && (cfg.api_key || cfg.base_url || cfg.model));
  var hasPerAgent = !!(cfg && cfg.agent_models && Object.keys(cfg.agent_models).length > 0);
  var configured = hasGlobal || hasPerAgent;
  notice.style.display = configured ? 'none' : 'block';
}

// ── localStorage helpers ──────────────────────────────────
function _loadLlmConfig() {
  try {
    return JSON.parse(localStorage.getItem('ai_berkshire_llm') || 'null');
  } catch(e) { return null; }
}

function _saveLlmConfig(cfg) {
  if (cfg) localStorage.setItem('ai_berkshire_llm', JSON.stringify(cfg));
  else localStorage.removeItem('ai_berkshire_llm');
}

// Build the per-request config object sent to the server.
// Returns null when user wants server defaults.
// per_agent_enabled / agent_models：按Agent分配不同模型（可选功能），
// 仅在 per_agent_enabled 开关开启时发送。
function getLlmConfig() {
  var cfg = _loadLlmConfig();
  if (!cfg) return null;
  var out = {};
  if (cfg.model) out.model = cfg.model;
  if (cfg.base_url) out.base_url = cfg.base_url;
  if (cfg.api_key) out.api_key = cfg.api_key;
  if (cfg.per_agent_enabled) {
    out.per_agent_enabled = true;
    if (cfg.agent_models && Object.keys(cfg.agent_models).length) {
      // Strip _provider (UI-only field) before sending
      var clean = {};
      Object.keys(cfg.agent_models).forEach(function(k) {
        var v = cfg.agent_models[k];
        if (typeof v === 'string') { clean[k] = v; return; }
        var sub = {};
        if (v.model) sub.model = v.model;
        if (v.base_url) sub.base_url = v.base_url;
        if (v.api_key) sub.api_key = v.api_key;
        if (Object.keys(sub).length) clean[k] = sub;
      });
      if (Object.keys(clean).length) out.agent_models = clean;
    }
  }
  return Object.keys(out).length ? out : null;
}

// ── Auth headers ──────────────────────────────────────────
function getAuthHeaders() {
  var jwt = localStorage.getItem('ai_berkshire_jwt') || '';
  if (!jwt) return {};
  return { 'Authorization': 'Bearer ' + jwt };
}

function getWsToken() {
  return localStorage.getItem('ai_berkshire_jwt') || '';
}

async function loginWithToken(secret) {
  var res = await fetch('/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ token: secret })
  });
  if (!res.ok) {
    var err = await res.json().catch(function() { return {}; });
    throw new Error(err.detail || '登录失败');
  }
  var data = await res.json();
  if (data.access_token) {
    localStorage.setItem('ai_berkshire_jwt', data.access_token);
  }
  return data;
}

// ── Modal ─────────────────────────────────────────────────
function openLlmModal() {
  var cfg = _loadLlmConfig();
  var preset = (cfg && cfg._preset) || 'deepseek';

  // Restore form
  document.getElementById('llm-preset').value = preset;
  document.getElementById('llm-model').value = (cfg && cfg.model) || '';
  document.getElementById('llm-base-url').value = (cfg && cfg.base_url) || '';
  // Keep the stored key — wiping it here silently drops the key on re-save
  document.getElementById('llm-api-key').value = (cfg && cfg.api_key) || '';
  

  // Trigger UI refresh
  onProviderChange();
  // If we have a stored preset, select the matching model in dropdown
  if (preset && cfg && cfg.model) {
    var sel = document.getElementById('llm-model-select');
    for (var i = 0; i < sel.options.length; i++) {
      if (sel.options[i].value === cfg.model) {
        sel.value = cfg.model;
        break;
      }
    }
  }

  // Per-agent model: rebuild table + restore
  _rebuildPerAgentTable();
  var paEnabled = !!(cfg && cfg.per_agent_enabled);
  document.getElementById('llm-per-agent-enabled').checked = paEnabled;
  // Ensure per-agent block is visible when checkbox is on (onProviderChange may have hidden it)
  if (paEnabled || (cfg && cfg.agent_models && Object.keys(cfg.agent_models).length)) {
    document.getElementById('llm-per-agent-block').style.display = 'block';
  }
  updateUploadVisibility();
  onPerAgentToggle();

  document.getElementById('llm-test-result').textContent = '';
  document.getElementById('llm-modal').style.display = 'flex';
}

function closeLlmModal() {
  document.getElementById('llm-modal').style.display = 'none';
}

// When provider dropdown changes, rebuild the model dropdown and show/hide fields.
function onProviderChange() {
  var preset = document.getElementById('llm-preset').value;
  var modelSelect = document.getElementById('llm-model-select');
  var modelInput = document.getElementById('llm-model');
  var customFields = document.getElementById('llm-custom-fields');

  if (!preset) {
    // Server default — hide all fields
    modelSelect.style.display = 'none';
    modelInput.style.display = 'none';
    customFields.style.display = 'none';
        return;
  }

  var info = LLM_PROVIDER_PRESETS[preset];
  if (info && info.models && info.models.length) {
    // Known provider with a model list — show dropdown
    modelSelect.innerHTML = '<option value="">请选择模型</option>';
    info.models.forEach(function(m) {
      var isMulti = _MULTIMODAL_MODELS.some(function(k) { return m.toLowerCase().indexOf(k) >= 0; });
      var tag = isMulti ? ' 📎' : '';
      modelSelect.innerHTML += '<option value="' + m + '">' + m + tag + '</option>';
    });
    modelSelect.style.display = 'block';
    modelInput.style.display = 'none';
  } else {
    // Custom or provider without a known list — show free-form input
    modelSelect.style.display = 'none';
    modelInput.style.display = 'block';
  }

  if (preset === 'custom') {
    customFields.style.display = 'block';
  } else {
    // Pre-fill base_url from preset
    document.getElementById('llm-base-url').value = (info && info.base_url) || '';
    customFields.style.display = 'block';  // always show so user can override key
  }
    // Per-agent block: only show for multi-agent skills (dynamically when modal opens)
  _rebuildPerAgentTable();
}

// When a model is picked from the dropdown, sync it to the hidden input for save.
function onModelSelectChange() {
  document.getElementById('llm-model').value = document.getElementById('llm-model-select').value;
}

// ── Per-agent model assignment (optional feature) ─────────
// Each agent can independently choose provider → model → base_url → api_key.
// Unconfigured agents fall back to the global (top-level) LLM config.

// Per-agent provider dropdown options: "跟随全局" + all providers from LLM_PROVIDER_PRESETS
function _paProviderOptions(selected) {
  var opts = '';
  Object.keys(LLM_PROVIDER_PRESETS).forEach(function(k) {
    var p = LLM_PROVIDER_PRESETS[k];
    opts += '<option value="' + k + '"' + (k === selected ? ' selected' : '') + '>' + escHtml(p.label) + '</option>';
  });
  return opts;
}

// Get agent names for the active skill (multi-agent only)
function _getActiveSkillAgents() {
  if (!currentSkill || !currentSkill.is_multi_agent || !currentSkill.agents) return [];
  return currentSkill.agents;
}

// Rebuild the per-agent table: agent label + provider + model + url + key per row.
// Team Lead appended at end.
function _rebuildPerAgentTable() {
  var table = document.getElementById('llm-per-agent-table');
  var block = document.getElementById('llm-per-agent-block');
  var agents = _getActiveSkillAgents();
  if (!agents.length) {
    // Still show block if user has saved per-agent config from previous session
    var _savedCfg = _loadLlmConfig();
    if (!_savedCfg || !_savedCfg.agent_models || !Object.keys(_savedCfg.agent_models).length) {
      block.style.display = 'none'; return;
    }
  }
  block.style.display = 'block';

  var cfg = _loadLlmConfig();
  var stored = (cfg && cfg.agent_models) || {};
  var allNames = agents.concat(['team-lead']);
  var rows = '';

  allNames.forEach(function(name) {
    var isTL = (name === 'team-lead');
    var label = isTL ? 'Team Lead' : _getAgentLabel(name);
    var rowClass = isTL ? ' per-agent-row-tl' : '';
    var agentCfg = stored[name] || {};
    // Support both legacy string and new dict format
    if (typeof agentCfg === 'string') agentCfg = { model: agentCfg };

    var paProvider = agentCfg._provider || '';
    var paModel = agentCfg.model || '';
    var paUrl = agentCfg.base_url || '';
    var paKey = agentCfg.api_key || '';
    var showFields = !!paProvider;  // show url/key when provider is set

    rows += '<div class="per-agent-row' + rowClass + '" data-agent="' + escHtml(name) + '">' +
      '<span class="agent-label">' + escHtml(label) + '</span>' +
      '<select class="pa-provider" onchange="_onPaProviderChange(this)" style="width:120px">' +
      _paProviderOptions(paProvider) +
      '</select>' +
      '<span class="pa-model-wrap" style="' + (showFields ? '' : 'display:none') + '">' +
      '<input type="text" class="pa-model" value="' + escHtml(paModel) +
      '" placeholder="模型名" style="width:130px">' +
      '</span>' +
      '<span class="pa-extra" style="' + (showFields ? '' : 'display:none') + '">' +
      '<input type="text" class="pa-url" value="' + escHtml(paUrl) +
      '" placeholder="Base URL" style="width:170px">' +
      '<input type="password" class="pa-key" value="' + escHtml(paKey) +
      '" placeholder="API Key" style="width:140px">' +
      '</span>' +
      '<button class="pa-test-btn" onclick="_onPaTest(this)"' + (showFields ? '' : ' style="display:none"') + '>测试</button>' +
      '<button class="pa-save-btn" onclick="_onPaSave(this)"' + (showFields ? '' : ' style="display:none"') + '>保存</button>' +
      '<span class="pa-test-result"></span>' +
      '</div>';
  });

  if (rows) {
    rows += '<p class="modal-tip" style="margin-top:8px">未指定服务商的Agent将使用上方全局模型配置。</p>';
  }
  table.innerHTML = rows;
}

// When a per-agent provider changes, show/hide model/url/key fields and auto-fill URL
function _onPaProviderChange(sel) {
  var row = sel.closest('.per-agent-row');
  var provider = sel.value;
  var modelWrap = row.querySelector('.pa-model-wrap');
  var extra = row.querySelector('.pa-extra');
  if (provider) {
    modelWrap.style.display = '';
    extra.style.display = '';
    // Auto-fill base_url from provider preset
    var info = LLM_PROVIDER_PRESETS[provider];
    var urlInput = row.querySelector('.pa-url');
    if (info && info.base_url && !urlInput.value) {
      urlInput.value = info.base_url;
    }
    // Read current model value from whichever element exists
    var curModelEl = row.querySelector('.pa-model-sel') || row.querySelector('.pa-model');
    var curModel = (curModelEl && curModelEl.value) || '';
    // If provider has known models, swap to dropdown
    if (info && info.models && info.models.length) {
      var selHtml = '<select class="pa-model-sel" style="width:130px"><option value="">请选择</option>';
      info.models.forEach(function(m) {
        var isMulti = _MULTIMODAL_MODELS.some(function(k) { return m.toLowerCase().indexOf(k) >= 0; });
        var tag = isMulti ? ' 📎' : '';
        selHtml += '<option value="' + m + '"' + (m === curModel ? ' selected' : '') + '>' + m + tag + '</option>';
      });
      selHtml += '</select>';
      modelWrap.innerHTML = selHtml;
    } else {
      modelWrap.innerHTML = '<input type="text" class="pa-model" value="' + escHtml(curModel) +
        '" placeholder="模型名" style="width:130px">';
    }
  } else {
    modelWrap.style.display = 'none';
    extra.style.display = 'none';
  }
  // Show/hide test/save buttons + clear result
  var testBtn = row.querySelector('.pa-test-btn');
  var saveBtn = row.querySelector('.pa-save-btn');
  var testResult = row.querySelector('.pa-test-result');
  if (testBtn) testBtn.style.display = provider ? '' : 'none';
  if (saveBtn) saveBtn.style.display = provider ? '' : 'none';
  if (testResult) testResult.textContent = '';
}

// Per-agent test connection: reads current row config, calls /api/llm/test
async function _onPaTest(btn) {
  var row = btn.closest('.per-agent-row');
  var resultEl = row.querySelector('.pa-test-result');
  var modelEl = row.querySelector('.pa-model-sel') || row.querySelector('.pa-model');
  var model = (modelEl || {}).value || '';
  var url = (row.querySelector('.pa-url') || {}).value || '';
  var key = (row.querySelector('.pa-key') || {}).value || '';

  if (!model) { resultEl.textContent = '请填写模型名'; resultEl.className = 'pa-test-result err'; return; }

  resultEl.textContent = '测试中...';
  resultEl.className = 'pa-test-result';
  btn.disabled = true;

  var cfg = { model: model };
  if (url) cfg.base_url = url;
  if (key) cfg.api_key = key;

  try {
    var res = await fetch('/api/llm/test', {
      method: 'POST',
      headers: Object.assign({ 'Content-Type': 'application/json' }, getAuthHeaders()),
      body: JSON.stringify({ llm_config: cfg })
    });
    if (res.status === 401 || res.status === 403) {
      resultEl.textContent = '登录过期';
      resultEl.className = 'pa-test-result err';
      return;
    }
    var data = await res.json();
    if (data.ok) {
      resultEl.textContent = '✓ ' + (data.reply || '').slice(0, 30);
      resultEl.className = 'pa-test-result ok';
    } else {
      resultEl.textContent = '✗ ' + (data.error || '失败').slice(0, 40);
      resultEl.className = 'pa-test-result err';
    }
  } catch(e) {
    resultEl.textContent = '✗ ' + e.message.slice(0, 40);
    resultEl.className = 'pa-test-result err';
  } finally {
    btn.disabled = false;
  }
}

// Per-agent save: reads current row config, persists to localStorage immediately
function _onPaSave(btn) {
  var row = btn.closest('.per-agent-row');
  var agent = row.dataset.agent;
  var resultEl = row.querySelector('.pa-test-result');
  var modelEl = row.querySelector('.pa-model-sel') || row.querySelector('.pa-model');
  var model = (modelEl || {}).value || '';
  var url = (row.querySelector('.pa-url') || {}).value || '';
  var key = (row.querySelector('.pa-key') || {}).value || '';
  var provider = (row.querySelector('.pa-provider') || {}).value || '';

  if (!model) { resultEl.textContent = '请填写模型名'; resultEl.className = 'pa-test-result err'; return; }

  var cfg = _loadLlmConfig() || {};
  var agentModels = cfg.agent_models || {};
  var sub = { model: model };
  if (url) sub.base_url = url;
  if (key) sub.api_key = key;
  if (provider) sub._provider = provider;
  agentModels[agent] = sub;
  cfg.agent_models = agentModels;
  cfg.per_agent_enabled = true;
  _saveLlmConfig(cfg);
  updateLlmNotice();
  updatePoweredBy();

  resultEl.textContent = '✓ 已保存';
  resultEl.className = 'pa-test-result ok';
  setTimeout(function() { resultEl.textContent = ''; }, 1500);
}

// Toggle per-agent fields visibility
function onPerAgentToggle() {
  var enabled = document.getElementById('llm-per-agent-enabled').checked;
  // Rebuild table when enabling, so it always reflects current skill's agents
  if (enabled) _rebuildPerAgentTable();
  document.getElementById('llm-per-agent-fields').style.display = enabled ? 'block' : 'none';
}

// ── Save / Reset / Test ───────────────────────────────────
function saveLlmConfig() {
  var preset = document.getElementById('llm-preset').value;
  var model = document.getElementById('llm-model').value.trim();
  var baseUrl = document.getElementById('llm-base-url').value.trim();
  var apiKey = document.getElementById('llm-api-key').value.trim();



  if (!model && preset !== 'custom') {
    showToast('请选择模型', 'error');
    return;
  }

  // Non-DeepSeek cloud providers reject the server's DeepSeek key — the
  // visitor MUST supply their own key, otherwise every request will 401.
  if (!apiKey && preset !== 'custom' && preset !== 'deepseek') {
    showToast('使用「' + (LLM_PROVIDER_PRESETS[preset] ? LLM_PROVIDER_PRESETS[preset].label : preset) +
      '」需要填写你自己的 API Key（不填会拿服务器 DeepSeek Key 去请求，必然 401）', 'error');
    return;
  }

  // Per-agent model config: read provider + model + url + key from each row
  var perAgentEnabled = document.getElementById('llm-per-agent-enabled').checked;
  var agentModels = {};
  if (perAgentEnabled) {
    var rows = document.querySelectorAll('#llm-per-agent-table .per-agent-row');
    for (var ri = 0; ri < rows.length; ri++) {
      var row = rows[ri];
      var agent = row.dataset.agent;
      var provider = (row.querySelector('.pa-provider') || {}).value || '';
      if (!provider) continue;  // no provider = use global config
      // Read model (could be select or text input)
      var modelEl = row.querySelector('.pa-model-sel') || row.querySelector('.pa-model');
      var model = (modelEl || {}).value || '';
      if (!model) continue;
      var url = (row.querySelector('.pa-url') || {}).value || '';
      var key = (row.querySelector('.pa-key') || {}).value || '';
      var sub = { model: model };
      if (url) sub.base_url = url;
      if (key) sub.api_key = key;
      sub._provider = provider;  // stored for UI restore, not sent to server
      agentModels[agent] = sub;
    }
  }

  var cfg = { _preset: preset };
  if (model) cfg.model = model;
  if (baseUrl) cfg.base_url = baseUrl;
  if (apiKey) cfg.api_key = apiKey;
  
  // Per-agent model: switch + mapping
  if (perAgentEnabled) {
    cfg.per_agent_enabled = true;
    if (Object.keys(agentModels).length) cfg.agent_models = agentModels;
  }

  _saveLlmConfig(cfg);
  updateUploadVisibility();
  updatePoweredBy();
  closeLlmModal();
  showToast('模型配置已保存', 'info');
}

function resetLlmConfig() {
  document.getElementById('llm-preset').value = '';
  document.getElementById('llm-model').value = '';
  document.getElementById('llm-model-select').innerHTML = '<option value="">请选择模型</option>';
  document.getElementById('llm-base-url').value = '';
  document.getElementById('llm-api-key').value = '';
  document.getElementById('llm-per-agent-enabled').checked = false;
  document.getElementById('llm-per-agent-table').innerHTML = '';
  document.getElementById('llm-per-agent-fields').style.display = 'none';
  document.getElementById('llm-test-result').textContent = '';
  onProviderChange();
  _saveLlmConfig(null);
  showToast('已清除所有自定义配置', 'info');
}

async function testLlmConfig() {
  var resultEl = document.getElementById('llm-test-result');
  var btn = document.getElementById('btn-llm-test');

  var cfg = {};
  var model = document.getElementById('llm-model').value.trim();
  var baseUrl = document.getElementById('llm-base-url').value.trim();
  var apiKey = document.getElementById('llm-api-key').value.trim();
  if (model) cfg.model = model;
  if (baseUrl) cfg.base_url = baseUrl;
  if (apiKey) cfg.api_key = apiKey;
  

  if (!cfg.model && !cfg.base_url && !cfg.api_key) {
    resultEl.textContent = '请先填写配置';
    resultEl.className = 'llm-test-result err';
    return;
  }

  resultEl.textContent = '测试中...';
  resultEl.className = 'llm-test-result';
  btn.disabled = true;

  try {
    var url = '/api/llm/test';
    var res = await fetch(url, {
      method: 'POST',
      headers: Object.assign({ 'Content-Type': 'application/json' }, getAuthHeaders()),
      body: JSON.stringify({ llm_config: cfg })
    });
    if (res.status === 401 || res.status === 403) {
      // JWT expired (24h TTL) — say so instead of a misleading "连接失败"
      localStorage.removeItem('ai_berkshire_jwt');
      resultEl.textContent = '✗ 登录已过期（令牌24小时有效），即将跳转重新登录...';
      resultEl.className = 'llm-test-result err';
      setTimeout(function() { location.reload(); }, 1500);
      return;
    }
    if (!res.ok) {
      var errText = await res.text().catch(function() { return ''; });
      resultEl.textContent = '✗ 服务器返回 ' + res.status + '：' + errText.slice(0, 200);
      resultEl.className = 'llm-test-result err';
      return;
    }
    var data = await res.json();
    if (data.ok) {
      var note = data.using_server_key ? '（使用服务器 Key）' : '';
      resultEl.textContent = '✓ 连接成功！模型 ' + (data.model || '?') + ' → ' + (data.reply || '') + note;
      resultEl.className = 'llm-test-result ok';
      if (!data.model) {
        resultEl.textContent = '⚠ 连接成功但模型名为空，请填写模型名称';
        resultEl.className = 'llm-test-result err';
      }
    } else {
      resultEl.textContent = '✗ ' + (data.error || '连接失败');
      resultEl.className = 'llm-test-result err';
    }
  } catch(e) {
    resultEl.textContent = '✗ 网络错误: ' + e.message;
    resultEl.className = 'llm-test-result err';
  } finally {
    btn.disabled = false;
  }
}

// ==================== Input Validation & History ====================
// Per-skill format checks. Return an error message, or null when OK.
var ARG_VALIDATORS = {
  'portfolio-review': function(a) {
    return a.indexOf('%') >= 0 ? null : '持仓清单需要包含仓位百分比，如：腾讯30%,美团20%,现金30%';
  },
  'earnings-review': function(a) {
    var trimmed = a.trim();
    // Detect quarter pattern: 2025Q4, 2025 Q4, etc.
    var qMatch = trimmed.match(/(\d{4})\s*Q([1-4])/);
    var hasLatest = trimmed.indexOf('最新') >= 0;
    if (!trimmed || (!qMatch && !hasLatest)) {
      return '需要同时提供公司名和季度，如：腾讯 2025Q4 / 腾讯2025Q4 / 最新';
    }
    // Check for future quarters
    if (qMatch) {
      var year = parseInt(qMatch[1]), quarter = parseInt(qMatch[2]);
      var now = new Date();
      var curYear = now.getFullYear(), curQuarter = Math.floor(now.getMonth() / 3) + 1;
      var availYear = curYear, availQuarter = curQuarter - 1;
      if (availQuarter === 0) { availQuarter = 4; availYear--; }
      if (year > availYear || (year === availYear && quarter > availQuarter)) {
        return '⚠ ' + year + 'Q' + quarter + ' 财报尚未发布！最新可用为 ' + availYear + 'Q' + availQuarter + '。请使用已发布的季度或输入"最新"';
      }
    }
    return null;
  },
  'earnings-team': function(a) {
    var trimmed = a.trim();
    var qMatch = trimmed.match(/(\d{4})\s*Q([1-4])/);
    var hasLatest = trimmed.indexOf('最新') >= 0;
    if (!trimmed || (!qMatch && !hasLatest)) {
      return '需要同时提供公司名和季度，如：腾讯 2025Q4 / 腾讯2025Q4 / 最新';
    }
    // Check for future quarters
    var qMatch = trimmed.match(/(\d{4})\s*Q([1-4])/);
    if (qMatch) {
      var year = parseInt(qMatch[1]), quarter = parseInt(qMatch[2]);
      var now = new Date();
      var curYear = now.getFullYear(), curQuarter = Math.floor(now.getMonth() / 3) + 1;
      var availYear = curYear, availQuarter = curQuarter - 1;
      if (availQuarter === 0) { availQuarter = 4; availYear--; }
      if (year > availYear || (year === availYear && quarter > availQuarter)) {
        return '⚠ ' + year + 'Q' + quarter + ' 财报尚未发布！最新可用为 ' + availYear + 'Q' + availQuarter + '。请使用已发布的季度或输入"最新"';
      }
    }
    return null;
  },
  'management-deep-dive': function(a) {
    return a.trim().length >= 2 ? null : '请输入公司名，如：腾讯 / 茅台 / 美团';
  },
  'investment-research': function(a) {
    return a.trim().length >= 2 ? null : '请输入公司名或股票代码，如：腾讯 / 0700.HK / 600519';
  },
  'investment-team': function(a) {
    return a.trim().length >= 2 ? null : '请输入公司名或股票代码，如：腾讯 / 0700.HK / 600519';
  },
  'investment-checklist': function(a) {
    return a.trim().length >= 2 ? null : '请输入公司名或股票代码（支持多个逗号分隔），如：腾讯,茅台,美团';
  },
  'financial-data': function(a) {
    return a.trim().length >= 2 ? null : '请输入公司名或股票代码，如：腾讯 / 600519';
  },
  'industry-research': function(a) {
    return a.trim().length >= 2 ? null : '请输入行业名称，如：半导体 / 新能源 / 消费';
  },
  'industry-funnel': function(a) {
    return a.trim().length >= 2 ? null : '请输入行业或方向，如：AI应用 / 光伏 / 创新药';
  },
  'quality-screen': function(a) {
    return a.trim().length >= 2 ? null : '请输入行业/指数/主题，如：沪深300 / 半导体';
  },
  'bottleneck-hunter': function(a) {
    return a.trim().length >= 2 ? null : '请输入超级趋势方向，如：AI算力 / 固态电池';
  }
};

function validateArgs(skill, args) {
  if (!args) {
    // daily-briefing explicitly supports empty input (今日日报)
    if (skill.name === 'daily-briefing') return null;
    return '请输入分析目标，如：' + (skill.input_hint || '公司名');
  }
  var v = ARG_VALIDATORS[skill.name];
  return v ? v(args) : null;
}

function saveArgHistory(args) {
  if (!args) return;
  try {
    var list = JSON.parse(localStorage.getItem('ai_berkshire_arg_history') || '[]');
    list = list.filter(function(x) { return x !== args; });
    list.unshift(args);
    localStorage.setItem('ai_berkshire_arg_history', JSON.stringify(list.slice(0, 20)));
    renderArgHistory();
  } catch(e) {}
}

function renderArgHistory() {
  try {
    var list = JSON.parse(localStorage.getItem('ai_berkshire_arg_history') || '[]');
    document.getElementById('arg-history').innerHTML = list.map(function(a) {
      return '<option value="' + escHtml(a) + '"></option>';
    }).join('');
  } catch(e) {}
}

// ==================== Progress Timer ====================
function startProgressTimer() {
  stopProgressTimer();
  _progressStartTs = Date.now();
  var el = document.getElementById('progress-timer');
  el.textContent = '0:00';
  _progressTimer = setInterval(function() {
    var sec = Math.floor((Date.now() - _progressStartTs) / 1000);
    var m = Math.floor(sec / 60), s = sec % 60;
    el.textContent = m + ':' + String(s).padStart(2, '0');
  }, 1000);
}

function stopProgressTimer() {
  if (_progressTimer) { clearInterval(_progressTimer); _progressTimer = null; }
}

// ==================== Research ====================
// ==================== File Upload ====================
var _uploadedFiles = [];  // extracted text from uploaded files

// Known multimodal models
var _MULTIMODAL_MODELS = ['gpt-4o', 'gpt-4-turbo', 'gpt-4-vision', 'claude-sonnet-4', 'claude-3', 'claude-3.5', 'gemini', 'glm-4v', 'qwen-vl', 'qwenvl', 'llava', 'pixtral', 'doubao-vision', 'yi-vision', 'grok-vision', 'gemini-2'];

function updateUploadVisibility() {
  var cfg = _loadLlmConfig();
  var hasVision = !!(cfg && cfg.vision_model);
  // Check if main model or vision model is multimodal
  var mainModel = (cfg && cfg.model || '').toLowerCase();
  var visionModel = (cfg && cfg.vision_model || '').toLowerCase();
  var isMulti = _MULTIMODAL_MODELS.some(function(m) {
    return mainModel.indexOf(m) >= 0 || visionModel.indexOf(m) >= 0;
  });
  document.getElementById('file-upload-row').style.display = (hasVision || isMulti) ? '' : 'none';
}

async function handleFileUpload(fileList) {
  if (!fileList || !fileList.length) return;
  var status = document.getElementById('file-status');
  var preview = document.getElementById('file-preview');
  var formData = new FormData();
  var names = [];
  
  for (var i = 0; i < fileList.length; i++) {
    formData.append('files', fileList[i]);
    names.push(fileList[i].name);
  }
  
  status.textContent = '处理中...';
  preview.style.display = 'none';
  
  try {
    var headers = {};
    Object.assign(headers, getAuthHeaders());
    // Append vision model + credentials from config
    var llmCfg = getLlmConfig() || {};
    var visionModel = llmCfg.vision_model || '';
    // Auto-use main model if it's multimodal and no vision model specified
    if (!visionModel && llmCfg.model) {
      var mainLower = llmCfg.model.toLowerCase();
      var isMulti = _MULTIMODAL_MODELS.some(function(k) { return mainLower.indexOf(k) >= 0; });
      if (isMulti) visionModel = llmCfg.model;
    }
    if (visionModel) {
      formData.append('vision_model', visionModel);
      if (llmCfg.base_url) formData.append('vision_base_url', llmCfg.base_url);
      if (llmCfg.api_key) formData.append('vision_api_key', llmCfg.api_key);
    }
    var res = await fetch('/api/upload', { method: 'POST', headers: headers, body: formData });
    if (!res.ok) {
      var err = await res.json().catch(function() { return {}; });
      throw new Error(err.detail || '上传失败 (' + res.status + ')');
    }
    var data = await res.json();
    var html = '<div class="fp-header">已提取 ' + data.files.length + ' 个文件的内容（将自动注入研究）</div>';
    var allText = [];
    data.files.forEach(function(f) {
      html += '<div class="fp-item">';
      html += '<span class="fp-filename">' + escHtml(f.filename) + '</span>';
      if (f.error) {
        html += ' <span class="fp-error">✗ ' + escHtml(f.error) + '</span>';
      } else {
        if (f.summary) {
          // UI: always show AI summary for human preview
          html += ' <span style="color:#6b8e6b;font-size:0.75rem">🤖 AI摘要 (' + f.method + ')</span>';
          html += '<div class="fp-summary">' + escHtml(f.summary) + '</div>';
          // Injection: use original if short, summary if long
          var MAX_INJECT = 5000;
          if (f.text && f.text.length <= MAX_INJECT) {
            allText.push('【文件：' + f.filename + '】\n' + f.text);
            html += ' <span style="color:#8c8273;font-size:0.7rem">（注入原文 ' + f.text.length + '字）</span>';
          } else {
            allText.push('【文件：' + f.filename + ' - AI摘要】\n' + f.summary);
            html += ' <span style="color:#8c8273;font-size:0.7rem">（原文 ' + (f.text ? f.text.length : 0) + '字过长，注入摘要）</span>';
          }
        } else {
          allText.push('【文件：' + f.filename + '】\n' + f.text);
          var preview = f.text ? f.text.slice(0, 100) + (f.text.length > 100 ? '...' : '') : '';
          html += ' <span style="color:#8c8273;font-size:0.75rem">(' + f.method + ', ' + (f.text ? f.text.length : 0) + '字)</span>';
          html += '<div style="color:#8c8273;font-size:0.72rem;margin-top:2px">' + escHtml(preview) + '</div>';
        }
      }
      html += '</div>';
    });preview.innerHTML = html;
    preview.style.display = 'block';
    _uploadedFiles = allText;
    status.textContent = '✓ ' + allText.length + ' 个文件已就绪';
    status.style.color = '#6b8e6b';
    
    // If no text in arg-field, suggest the file content
    var af = document.getElementById('arg-field');
    if (!af.value.trim() && allText.length) {
      af.value = names.join(', ');
    }
  } catch(e) {
    status.textContent = '✗ ' + e.message;
    status.style.color = '#b85c5c';
    preview.style.display = 'none';
  }
}

async function startResearch() {
  var args = document.getElementById('arg-field').value.trim();
  // Append uploaded file content as reference material (not analysis target)
  if (_uploadedFiles.length) {
    // Try to guess target from filename if user didn't specify
    if (!args) {
      var fi = document.getElementById('file-input');
      if (fi && fi.files && fi.files.length) {
        var fn = fi.files[0].name.replace(/\.[^.]+$/, '');  // strip extension
        fn = fn.replace(/[_\-]/g, ' ').replace(/\s+/g, ' ').trim();
        // Extract first meaningful word group (company name)
        var parts = fn.split(/[【（(]/);
        args = parts[0].trim() || fn;
      }
    }
    args = (args || '分析上传的文件') + '\n\n【以下为上传文件的参考内容，请基于此进行分析】\n' + _uploadedFiles.join('\n\n');
    // Clear file preview immediately — content already injected into research
    document.getElementById('file-preview').style.display = 'none';
    document.getElementById('file-preview').innerHTML = '';
    document.getElementById('file-status').textContent = '';
    document.getElementById('file-status').style.color = '';
    var fi2 = document.getElementById('file-input');
    if (fi2) fi2.value = '';
  }
  if (!currentSkill) { showToast('请先选择技能', 'warning'); return; }

  // Block if no model configured (per-agent-only config also counts)
  var cfg = _loadLlmConfig();
  var hasGlobal = !!(cfg && (cfg.model || cfg.base_url || cfg.api_key));
  var hasPerAgent = !!(cfg && cfg.agent_models && Object.keys(cfg.agent_models).length);
  if (!hasGlobal && !hasPerAgent) {
    showToast('⚠ 请先在模型设置中配置供应商、模型和 API Key', 'error');
    document.getElementById('llm-notice').style.display = 'block';
    return;
  }

  var err = validateArgs(currentSkill, args);
  if (err) {
    showToast(err, 'warning');
    document.getElementById('input-hint').textContent = err;
    return;
  }

  var streamMode = document.getElementById('stream-mode').checked;
  var btn = document.getElementById('btn-research');
  var cancelBtn = document.getElementById('btn-cancel');
  btn.disabled = true;
  btn.textContent = '研究中...';
  cancelBtn.style.display = 'inline-block';
  cancelBtn.disabled = false;

  saveArgHistory(args);

  // Reset state
  _userCancelled = false;
  currentTaskId = null;
  _wsShouldReconnect = false;
  _uploadedFiles = [];
  if (_researchAbort) { _researchAbort.abort(); _researchAbort = null; }
  if (ws) { ws.close(); ws = null; }

  // Hide other areas
  document.getElementById('empty-state').style.display = 'none';
  document.getElementById('history-area').style.display = 'none';
  document.getElementById('compare-area').style.display = 'none';
  document.getElementById('result-area').style.display = 'none';
  document.getElementById('report-content').innerHTML = '';
  document.getElementById('report-meta').style.display = 'none';
  document.getElementById('restore-banner').style.display = 'none';
  document.getElementById('follow-up-area').style.display = 'none';
  document.getElementById('follow-up-qa').innerHTML = '';
  _followUpHistory = [];
  try { localStorage.removeItem('ai_berkshire_followup'); } catch(e) {}
  hideToc();
  currentReport = '';

  // Show progress
  var progressArea = document.getElementById('progress-area');
  progressArea.style.display = 'block';
  document.getElementById('progress-title').textContent =
    currentSkill.display_name + ': ' + (args || '今日日报');
  document.getElementById('progress-status').textContent = '运行中';
  document.getElementById('progress-status').className = 'status-badge running';
  document.getElementById('progressCount').textContent = '';
  startProgressTimer();

  // Build agent rows (mirror backend naming)
  var agentNames;
  if (currentSkill.series_mode && currentSkill.series_topics && currentSkill.series_topics.length) {
    agentNames = currentSkill.series_topics.map(function(t, i) { return 'article-' + (i + 1); });
  } else if (currentSkill.is_multi_agent && currentSkill.agents) {
    agentNames = currentSkill.agents;
  } else {
    agentNames = ['default'];
  }
  var agentDiv = document.getElementById('agent-progress');
  agentDiv.innerHTML = agentNames.map(function(name, i) {
    var topic = '';
    if (currentSkill.series_mode && currentSkill.series_topics && currentSkill.series_topics[i]) {
      topic = ' <span style="color:var(--text-secondary);font-size:0.7rem">' + escHtml(currentSkill.series_topics[i]) + '</span>';
    }
    return '<div class="agent-row" id="agent-' + i + '">' +
      '<div class="agent-dot pending"></div>' +
      '<span>' + escHtml(name) + topic + '</span>' +
      '<span style="color:var(--text-secondary);font-size:0.7rem">等待中</span>' +
      '<button class="agent-retry" onclick="retryFailedTask()" title="重试">⟳ 重试</button></div>';
  }).join('');

  // Stream mode now works for ALL skills via WebSocket:
  // single-agent streams chunks; multi-agent/series stream per-agent progress.
  if (streamMode) {
    await streamResearch(args);
  } else {
    await batchResearch(args);
  }
}

function cancelResearch() {
  _userCancelled = true;
  _wsShouldReconnect = false;
  // Ask the server to actually stop the LLM calls
  if (currentTaskId) {
    var headers = {};
    Object.assign(headers, getAuthHeaders());
    fetch('/api/cancel/' + currentTaskId, { method: 'POST', headers: headers })
      .catch(function() {});
  }
  if (_researchAbort) {
    _researchAbort.abort();
    showToast('已取消研究', 'warning');
  }
  if (ws) {
    ws.close();
    ws = null;
    showToast('已取消研究', 'warning');
  }
  finishResearch(false, '已取消');
  document.getElementById('btn-cancel').style.display = 'none';
}

async function streamResearch(args) {
  _wsShouldReconnect = true;
  _wsReconnectAttempts = 0;
  _streamResearchImpl(args);
}

function _streamResearchImpl(args) {
  var proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
  var url = proto + '//' + location.host + '/ws/research/' + currentSkill.name;

  // Timeout guard: if no data within 90s, fall back to batch mode
  var _wsTimeout = setTimeout(function() {
    if (!currentReport && _wsShouldReconnect) {
      showToast('WebSocket响应超时，自动切换到普通模式', 'warning');
      _wsShouldReconnect = false;
      if (ws) { ws.close(); ws = null; }
      batchResearch(args);
    }
  }, currentSkill && currentSkill.is_multi_agent ? 180000 : 90000);

  try {
    ws = new WebSocket(url);
    ws.onopen = function() {
      _wsReconnectAttempts = 0;
      var msg = { arguments: args };
      msg.token = getWsToken();
      var llmConfig = getLlmConfig();
      if (llmConfig) msg.llm_config = llmConfig;
      ws.send(JSON.stringify(msg));
    };

    ws.onmessage = function(event) {
      clearTimeout(_wsTimeout);
      var data = JSON.parse(event.data);
      if (data.type === 'started') {
        currentTaskId = data.task_id;
        _agentStreamBuffers = {};
      } else if (data.type === 'chunk') {
        if (data.agent) {
          // Event protocol v2: multi/series per-agent token stream.
          // Accumulate per agent; the assembled report still arrives in
          // 'complete', so the main report view is not disturbed.
          _agentStreamBuffers[data.agent] = (_agentStreamBuffers[data.agent] || '') + data.content;
          if (agentRowNames().indexOf(data.agent) >= 0) {
            updateAgentProgress(data.agent, 'running', '撰写中… ' + _agentStreamBuffers[data.agent].length + ' 字');
          }
        } else {
          currentReport += data.content;
          document.getElementById('progress-area').style.display = 'none';
          document.getElementById('result-area').style.display = 'block';
          scheduleRender();
        }
      } else if (data.type === 'progress') {
        updateAgentProgress(data.agent, data.status, data.message);
      } else if (data.type === 'context_ready') {
        // Event protocol v2: context assembly summary (info only)
        console.info('context_ready', data);
      } else if (data.type === 'tool_call') {
        // Event protocol v2: tool call observability (debug only)
        console.debug('tool_call', data);
      } else if (data.type === 'guard_warning') {
        // Event protocol v2: output gate warning (light notice)
        console.warn('guard_warning', data);
      } else if (data.type === 'cancelled') {
        // Event protocol v2: explicit cancel frame (legacy error cancelled still handled below)
        _wsShouldReconnect = false;
        finishResearch(false, data.message || '已被用户取消');
      } else if (data.type === 'complete') {
        _wsShouldReconnect = false;
        if (data.report) currentReport = data.report;
        finishResearch(true, null, { duration: data.duration_seconds, tokens: data.tokens });
      } else if (data.type === 'error') {
        _wsShouldReconnect = false;
        finishResearch(false, data.message);
      }
      // Unknown event types are ignored for forward compatibility.
    };

    ws.onerror = function() {
      // Will trigger onclose, handle reconnect there
    };
    ws.onclose = function(event) {
      if (_wsShouldReconnect && _wsReconnectAttempts < _WS_MAX_RECONNECT) {
        var delay = _WS_RECONNECT_DELAYS[_wsReconnectAttempts] || 10000;
        _wsReconnectAttempts++;
        showToast('连接断开，' + Math.round(delay/1000) + '秒后重试 (' + _wsReconnectAttempts + '/' + _WS_MAX_RECONNECT + ')', 'warning');
        setTimeout(function() {
          if (_wsShouldReconnect) _streamResearchImpl(args);
        }, delay);
      } else if (_wsShouldReconnect) {
        // Max retries reached — fall back to batch mode
        if (currentReport) {
          finishResearch(true);
        } else {
          showToast('WebSocket连接失败，自动切换到普通模式', 'warning');
          _wsShouldReconnect = false;
          if (ws) { ws.close(); ws = null; }
          batchResearch(args);
          return;
        }
      } else if (currentReport && !document.getElementById('result-area').style.display) {
        finishResearch(true);
      }
    };
  } catch (e) {
    finishResearch(false, e.message);
  }
}

// Throttled streaming render: re-parse the whole report at most every 150ms
// instead of on every token, which keeps long reports responsive.
function scheduleRender() {
  if (_renderScheduled) return;
  _renderScheduled = true;
  setTimeout(function() {
    _renderScheduled = false;
    renderReport(currentReport);
    var resultArea = document.getElementById('result-area');
    resultArea.scrollTop = resultArea.scrollHeight;
  }, 150);
}

async function batchResearch(args) {
  _researchAbort = new AbortController();
  // 30-minute budget: multi-agent / series runs legitimately take a long time.
  // On timeout we no longer report failure — the server keeps running and the
  // report will land in 历史报告.
  var timeout = setTimeout(function() { if(_researchAbort) _researchAbort.abort(); }, 1800000);
  try {
    var headers = { 'Content-Type': 'application/json' };
    Object.assign(headers, getAuthHeaders());
    var res = await fetch('/api/research', {
      method: 'POST',
      headers: headers,
      body: JSON.stringify({
        skill_name: currentSkill.name,
        arguments: args,
        stream: false,
        llm_config: getLlmConfig() || undefined
      }),
      signal: _researchAbort.signal
    });
    clearTimeout(timeout);
    var data = await res.json();
    if (data.task_id) currentTaskId = data.task_id;

    if (data.agent_results) {
      var total = data.agent_results.length;
      var done = data.agent_results.filter(function(r) { return r.status === 'completed' || r.status === 'success'; }).length;
      document.getElementById('progressCount').textContent = '完成 ' + done + '/' + total + ' Agent';
      data.agent_results.forEach(function(r, i) {
        updateAgentProgress(r.agent_name || r.name || ('agent-' + i), r.status, r.status === 'completed' ? '完成' : (r.error || ''));
      });
    }

    if (data.status === 'completed') {
      currentReport = data.report;
      updateAllAgents('completed');
      finishResearch(true, null, { duration: data.duration_seconds, tokens: data.tokens });
    } else {
      finishResearch(false, data.error || 'Unknown error');
    }
  } catch (e) {
    clearTimeout(timeout);
    if (e.name === 'AbortError') {
      if (_userCancelled) {
        finishResearch(false, '已取消');
      } else {
        showToast('等待超时：任务仍在后台运行，完成后可在「历史报告」中查看', 'warning');
        finishResearch(false, '等待超时，任务仍在后台运行，完成后请查看历史报告');
      }
    } else {
      finishResearch(false, e.message);
    }
  } finally {
    _researchAbort = null;
  }
}

function agentRowNames() {
  if (currentSkill && currentSkill.series_mode && currentSkill.series_topics && currentSkill.series_topics.length) {
    return currentSkill.series_topics.map(function(t, i) { return 'article-' + (i + 1); });
  }
  return (currentSkill && currentSkill.agents) || ['default'];
}

function updateAgentProgress(name, status, message) {
  var agentNames = agentRowNames();
  var idx = agentNames.indexOf(name);
  if (idx < 0) {
    // 'system' and other meta progress — surface in the count line
    if (message) document.getElementById('progressCount').textContent = message;
    return;
  }

  var row = document.getElementById('agent-' + idx);
  if (!row) return;

  var dot = row.querySelector('.agent-dot');
  var statusText = row.querySelector('span:last-child');

  dot.className = 'agent-dot ' + status;
  if (status === 'completed') {
    statusText.textContent = '完成';
    statusText.style.color = 'var(--accent-green)';
  } else if (status === 'running') {
    statusText.textContent = message || '分析中...';
    statusText.style.color = 'var(--accent)';
  } else if (status === 'failed') {
    statusText.textContent = message || '失败';
    statusText.style.color = 'var(--accent-red)';
    row.classList.add('failed');
  }

  var allRows = document.querySelectorAll('#agent-progress .agent-row');
  var done = 0;
  allRows.forEach(function(r) {
    if (r.querySelector('.agent-dot.completed')) done++;
  });
  document.getElementById('progressCount').textContent = '完成 ' + done + '/' + allRows.length + ' Agent';
}

function updateAllAgents(status) {
  agentRowNames().forEach(function(name, i) {
    var row = document.getElementById('agent-' + i);
    if (!row) return;
    row.querySelector('.agent-dot').className = 'agent-dot ' + status;
    row.querySelector('span:last-child').textContent = status === 'completed' ? '完成' : '';
  });
}

function finishResearch(success, errorMsg, meta) {
  stopProgressTimer();
  var btn = document.getElementById('btn-research');
  var cancelBtn = document.getElementById('btn-cancel');
  btn.disabled = false;
  btn.textContent = currentSkill && currentSkill.is_multi_agent
    ? '启动 ' + currentSkill.agent_count + ' Agent 并行研究'
    : '开始研究';
  cancelBtn.style.display = 'none';

  var statusEl = document.getElementById('progress-status');
  if (success) {
    statusEl.textContent = '完成';
    statusEl.className = 'status-badge completed';
  } else {
    statusEl.textContent = '失败';
    statusEl.className = 'status-badge failed';
    if (errorMsg) {
      // Save failed task for retry on next visit
      saveFailedTask(errorMsg);
      // Keep whatever partial content was already generated — it is often
      // still useful — and append the error instead of wiping the report.
      if (currentReport) {
        currentReport += '\n\n---\n\n> ⚠ **中断**：' + errorMsg + '（以上为已完成的部分内容）\n';
      } else {
        currentReport = '# 错误\n\n' + errorMsg;
      }
      showToast(errorMsg, 'error');
    }
  }

  if (currentReport && currentReport.indexOf('# 错误') !== 0) {
    document.getElementById('progress-area').style.display = 'none';
    document.getElementById('result-area').style.display = 'block';
    renderReport(currentReport);
    buildToc();

    // Duration / token cost line
    if (meta && (meta.duration || (meta.tokens && meta.tokens.total_tokens))) {
      var parts = [];
      if (meta.duration) parts.push('耗时 ' + fmtDuration(meta.duration));
      var tk = fmtTokens(meta.tokens);
      if (tk) parts.push('消耗 ' + tk);
      var metaEl = document.getElementById('report-meta');
      metaEl.textContent = parts.join(' · ');
      metaEl.style.display = 'block';
    }

    try {
      sessionStorage.setItem('ai_berkshire_report', currentReport);
      sessionStorage.setItem('ai_berkshire_report_meta', JSON.stringify({
        skill: currentSkill ? currentSkill.name : '',
        ts: Date.now()
      }));
    } catch(e) {}
  }

  _wsShouldReconnect = false;
  if (ws) { ws.close(); ws = null; }
  // Clear uploaded file preview after research completes
  _uploadedFiles = [];
  document.getElementById('file-preview').style.display = 'none';
  document.getElementById('file-preview').innerHTML = '';
  document.getElementById('file-status').textContent = '';
  document.getElementById('file-status').style.color = '';
  // Reset file input
  var fi = document.getElementById('file-input');
  if (fi) fi.value = '';
  localStorage.setItem('ai_berkshire_skill', currentSkill ? currentSkill.name : '');
}

// ==================== Rendering / TOC ====================
// ==================== Failed Task Persistence ====================
function saveFailedTask(errorMsg) {
  if (!currentSkill) return;
  try {
    var list = JSON.parse(localStorage.getItem('ai_berkshire_failed') || '[]');
    list.push({
      skill: currentSkill.name,
      skillLabel: currentSkill.display_name || currentSkill.name,
      arguments: document.getElementById('arg-field').value.trim(),
      error: errorMsg || '未知错误',
      ts: Date.now()
    });
    // Keep last 10 failed tasks
    localStorage.setItem('ai_berkshire_failed', JSON.stringify(list.slice(-10)));
  } catch(e) {}
}

function renderFailedTasks() {
  var el = document.getElementById('failed-tasks');
  try {
    var list = JSON.parse(localStorage.getItem('ai_berkshire_failed') || '[]');
  } catch(e) { el.style.display = 'none'; return; }
  if (!list.length) { el.style.display = 'none'; return; }
  
  var html = '<div style="font-size:0.85rem;color:#b85c5c;margin-bottom:8px">⚠ 上次有 ' + list.length + ' 个未完成的任务：</div>';
  list.forEach(function(t, i) {
    var when = new Date(t.ts).toLocaleString();
    html += '<div class="failed-task-card" id="ft-' + i + '">' +
      '<div class="ft-info">' +
      '<div class="ft-skill">' + escHtml(t.skillLabel) + '</div>' +
      '<div class="ft-args">' + escHtml(t.arguments || '(空)') + '</div>' +
      '<div class="ft-error">' + escHtml(t.error) + '</div>' +
      '<div class="ft-time">' + when + '</div>' +
      '</div>' +
      '<button class="btn-retry" onclick="retryFailedTask(' + i + ')">⟳ 继续</button>' +
      '<button class="btn-dismiss" onclick="dismissFailedTask(' + i + ')" title="忽略">✕</button>' +
      '</div>';
  });
  el.innerHTML = html;
  el.style.display = 'block';
}

function retryFailedTask(idx) {
  try {
    var list = JSON.parse(localStorage.getItem('ai_berkshire_failed') || '[]');
    if (idx >= list.length) return;
    var t = list[idx];
    // Remove this task from the list
    list.splice(idx, 1);
    localStorage.setItem('ai_berkshire_failed', JSON.stringify(list));
    // Re-render
    renderFailedTasks();
  updateUploadVisibility();
    // Select skill and start research
    selectSkill(t.skill);
    document.getElementById('arg-field').value = t.arguments || '';
    startResearch();
  } catch(e) { showToast('重试失败: ' + e.message, 'error'); }
}

function dismissFailedTask(idx) {
  try {
    var list = JSON.parse(localStorage.getItem('ai_berkshire_failed') || '[]');
    list.splice(idx, 1);
    localStorage.setItem('ai_berkshire_failed', JSON.stringify(list));
    renderFailedTasks();
  updateUploadVisibility();
  } catch(e) {}
}

function renderReport(md) {
  document.getElementById('report-content').innerHTML =
    DOMPurify.sanitize(marked.parse(md)) +
    '<div class="ai-disclaimer">该数据由AI在数据的基础上进行分析，仅供参考</div>';
  // Show follow-up area when a report is rendered
  document.getElementById('follow-up-area').style.display = 'block';
  // Restore follow-up Q&A history
  _loadFollowUpHistory();
}

// ==================== Follow-up Q&A ====================
var _followUpLoading = false;
var _followUpHistory = [];

function _saveFollowUpHistory() {
  var items = [];
  document.querySelectorAll('#follow-up-qa .follow-up-qa-item').forEach(function(el) {
    var isQ = el.classList.contains('follow-up-q');
    items.push({
      type: isQ ? 'q' : 'a',
      html: el.querySelector('.qa-content').innerHTML,
      label: el.querySelector('.qa-label').textContent
    });
  });
  _followUpHistory = items;
  try { localStorage.setItem('ai_berkshire_followup', JSON.stringify(items)); } catch(e) {}
}

function _loadFollowUpHistory() {
  try {
    var items = JSON.parse(localStorage.getItem('ai_berkshire_followup') || '[]');
    if (!items.length) return;
    _followUpHistory = items;
    var qa = document.getElementById('follow-up-qa');
    var html = '';
    items.forEach(function(item) {
      var cls = item.type === 'q' ? 'follow-up-q' : 'follow-up-a';
      html += '<div class="follow-up-qa-item ' + cls + '">' +
        '<div class="qa-label">' + escHtml(item.label) + '</div>' +
        '<div class="qa-content">' + item.html + '</div>' +
        '</div>';
    });
    qa.innerHTML = html;
    document.getElementById('follow-up-area').style.display = 'block';
  // Restore follow-up Q&A history
  _loadFollowUpHistory();
  } catch(e) {}
}

async function submitFollowUp() {
  if (_followUpLoading) return;
  var field = document.getElementById('follow-up-field');
  var question = field.value.trim();
  if (!question) return;
  if (!currentReport) { showToast('请先生成报告', 'warning'); return; }

  _followUpLoading = true;
  var btn = document.getElementById('btn-follow-up');
  btn.disabled = true;
  btn.textContent = '思考中...';
  field.disabled = true;

  // Show question immediately
  var qa = document.getElementById('follow-up-qa');
  var qId = 'fu-q-' + Date.now();
  qa.insertAdjacentHTML('beforeend',
    '<div class="follow-up-qa-item follow-up-q" id="' + qId + '">' +
    '<div class="qa-label">🙋 追问</div>' +
    '<div class="qa-content">' + escHtml(question) + '</div>' +
    '</div>');
  var aId = 'fu-a-' + Date.now();
  qa.insertAdjacentHTML('beforeend',
    '<div class="follow-up-qa-item follow-up-a" id="' + aId + '">' +
    '<div class="qa-label">🤖 AI 回复</div>' +
    '<div class="qa-content follow-up-loading">思考中...</div>' +
    '</div>');
  qa.scrollTop = qa.scrollHeight;

  try {
    var headers = { 'Content-Type': 'application/json' };
    Object.assign(headers, getAuthHeaders());
    var res = await fetch('/api/follow-up', {
      method: 'POST',
      headers: headers,
      body: JSON.stringify({
        report: currentReport,
        question: question,
        skill_name: currentSkill ? currentSkill.name : '',
        llm_config: getLlmConfig() || undefined
      })
    });
    if (!res.ok) {
      var err = await res.json().catch(function() { return {}; });
      throw new Error(err.detail || '请求失败 (' + res.status + ')');
    }
    var data = await res.json();
    document.getElementById(aId).querySelector('.qa-content').innerHTML =
      DOMPurify.sanitize(marked.parse(data.answer || '(无回复)'));
    // Persist Q&A to localStorage
    _saveFollowUpHistory();
  } catch(e) {
    document.getElementById(aId).querySelector('.qa-content').innerHTML =
      '<span style="color:var(--accent-red)">✗ ' + escHtml(e.message) + '</span>';
  } finally {
    _followUpLoading = false;
    btn.disabled = false;
    btn.textContent = '发送';
    field.disabled = false;
    field.value = '';
    field.focus();
    qa.scrollTop = qa.scrollHeight;
  }
}

function buildToc() {
  var toc = document.getElementById('report-toc');
  var headings = document.querySelectorAll('#report-content h1, #report-content h2, #report-content h3');
  if (!headings.length) { hideToc(); return; }
  var html = '<div class="toc-title">目录</div><ul>';
  headings.forEach(function(h, i) {
    var id = 'toc-h-' + i;
    h.id = id;
    var level = h.tagName.toLowerCase();
    html += '<li class="toc-' + level + '"><a href="javascript:void(0)" data-target="' + id + '" onclick="tocJump(\'' + id + '\')">' +
      escHtml(h.textContent) + '</a></li>';
  });
  html += '</ul>';
  toc.innerHTML = html;
}

function tocJump(id) {
  var el = document.getElementById(id);
  if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function toggleToc() {
  var toc = document.getElementById('report-toc');
  if (toc.style.display === 'none' || !toc.innerHTML) {
    if (!toc.innerHTML) buildToc();
    if (!toc.innerHTML) { showToast('报告暂无章节标题', 'warning'); return; }
    toc.style.display = 'block';
  } else {
    toc.style.display = 'none';
  }
}

function hideToc() {
  var toc = document.getElementById('report-toc');
  toc.style.display = 'none';
  toc.innerHTML = '';
}

// Scroll-spy: highlight current section in TOC
document.addEventListener('scroll', function(e) {
  var toc = document.getElementById('report-toc');
  if (!toc || toc.style.display === 'none') return;
  if (e.target && e.target.id !== 'result-area') return;
  var headings = document.querySelectorAll('#report-content h1, #report-content h2, #report-content h3');
  var current = null;
  headings.forEach(function(h) {
    if (h.getBoundingClientRect().top < 140) current = h.id;
  });
  toc.querySelectorAll('a').forEach(function(a) {
    a.classList.toggle('current', a.dataset.target === current);
  });
}, true);

// ==================== Report Actions ====================
function copyReport() {
  if (!currentReport) { showToast('没有可复制的内容', 'warning'); return; }
  navigator.clipboard.writeText(currentReport).then(function() {
    showToast('报告已复制到剪贴板', 'success');
  }).catch(function() {
    showToast('复制失败', 'error');
  });
}

function _reportFileBase() {
  var skill = currentSkill ? currentSkill.name : 'report';
  var args = (document.getElementById('arg-field').value || '').trim()
    .replace(/[\\/:*?"<>|\s]+/g, '_').slice(0, 24);
  var ts = new Date().toISOString().slice(0,19).replace(/:/g, '-');
  return (args ? skill + '_' + args : skill) + '_' + ts;
}

function downloadReport() {
  if (!currentReport) { showToast('没有可下载的内容', 'warning'); return; }
  var blob = new Blob([currentReport], { type: 'text/markdown' });
  var url = URL.createObjectURL(blob);
  var a = document.createElement('a');
  a.href = url;
  a.download = _reportFileBase() + '.md';
  a.click();
  URL.revokeObjectURL(url);
  showToast('已下载', 'success');
}

function exportHtml() {
  if (!currentReport) { showToast('没有可导出的内容', 'warning'); return; }
  var body = DOMPurify.sanitize(marked.parse(currentReport));
  var title = _reportFileBase();
  var html = '<!DOCTYPE html><html lang="zh-CN"><head><meta charset="UTF-8">' +
    '<meta name="viewport" content="width=device-width, initial-scale=1.0">' +
    '<title>' + escHtml(title) + '</title>' +
    '<style>body{font-family:\'Noto Serif SC\',\'Source Han Serif SC\',STSong,Georgia,serif;' +
    'max-width:760px;margin:0 auto;padding:32px 24px 60px;background:#f7f3e9;color:#3d3d3d;line-height:1.85}' +
    'h1{font-size:1.35rem;border-bottom:1px solid #d4c5a9;padding-bottom:10px;font-weight:400}' +
    'h2{color:#6b8e6b;font-weight:400;margin-top:28px}h3{color:#c4a77d;font-weight:400}' +
    'table{width:100%;border-collapse:collapse;margin:14px 0;font-size:0.85rem}' +
    'th{background:#f0ebe0;padding:8px 12px;text-align:left;border-bottom:1px solid #d4c5a9;font-weight:400}' +
    'td{padding:7px 12px;border-bottom:1px solid #e5dac8}' +
    'code{background:#f0ebe0;padding:2px 6px;border-radius:2px;color:#6b8e6b}' +
    'pre{background:#f0ebe0;padding:14px;border-radius:4px;overflow-x:auto}' +
    'blockquote{border-left:2px solid #c4a77d;padding:8px 18px;margin:14px 0;color:#8c8273;font-style:italic}' +
    'hr{border:none;border-top:1px solid #e5dac8;margin:28px 0}</style></head>' +
    '<body>' + body + '</body></html>';
  var blob = new Blob([html], { type: 'text/html' });
  var url = URL.createObjectURL(blob);
  var a = document.createElement('a');
  a.href = url;
  a.download = title + '.html';
  a.click();
  URL.revokeObjectURL(url);
  showToast('已导出 HTML', 'success');
}

function printReport() {
  if (!currentReport) { showToast('没有可打印的内容', 'warning'); return; }
  window.print();
}

function clearResult() {
  currentReport = '';
  document.getElementById('result-area').style.display = 'none';
  document.getElementById('report-content').innerHTML = '';
  document.getElementById('report-meta').style.display = 'none';
  document.getElementById('restore-banner').style.display = 'none';
  document.getElementById('follow-up-area').style.display = 'none';
  document.getElementById('follow-up-qa').innerHTML = '';
  _followUpHistory = [];
  try { localStorage.removeItem('ai_berkshire_followup'); } catch(e) {}
  hideToc();
  document.getElementById('empty-state').style.display = 'flex';
  try {
    sessionStorage.removeItem('ai_berkshire_report');
    sessionStorage.removeItem('ai_berkshire_report_meta');
  } catch(e) {}
}

// ==================== History ====================
function backToHome() {
  document.getElementById('result-area').style.display = 'none';
  document.getElementById('progress-area').style.display = 'none';
  document.getElementById('history-area').style.display = 'none';
  document.getElementById('compare-area').style.display = 'none';
  document.getElementById('empty-state').style.display = 'block';
}

async function showHistory() {
  document.getElementById('empty-state').style.display = 'none';
  document.getElementById('result-area').style.display = 'none';
  document.getElementById('progress-area').style.display = 'none';
  document.getElementById('compare-area').style.display = 'none';

  var historyArea = document.getElementById('history-area');
  var list = document.getElementById('history-list');
  document.getElementById('historySearch').value = '';
  _compareSelection.clear();
  updateCompareBtn();

  try {
    var headers = {};
    Object.assign(headers, getAuthHeaders());
    var res = await fetch('/api/reports', { headers: headers });
    var data = await res.json();
    _historyData = data.reports || [];
    renderHistory(_historyData);
  } catch (e) {
    list.innerHTML = '<p style="color:var(--accent-red)">加载失败</p>';
  }

  historyArea.style.display = 'block';
}

function filterHistory() {
  var q = document.getElementById('historySearch').value.toLowerCase();
  var filtered = _historyData.filter(function(r) {
    var hay = ((r.name || '') + ' ' + (r.arguments || '') + ' ' +
      (r.skill_name || '') + ' ' + skillDisplayName(r.skill_name || '')).toLowerCase();
    return hay.indexOf(q) >= 0;
  });
  renderHistory(filtered);
}

function renderHistory(reports) {
  var list = document.getElementById('history-list');
  if (!reports.length) {
    list.innerHTML = '<p style="color:var(--text-secondary)">暂无匹配报告</p>';
    return;
  }
  list.innerHTML = reports.map(function(r) {
    var safeName = escHtml(r.name || '');
    var args = (r.arguments || '').trim();
    var title = args || r.name;
    var metaParts = [];
    if (r.skill_name) metaParts.push(skillDisplayName(r.skill_name));
    metaParts.push(new Date(r.modified).toLocaleString());
    metaParts.push((r.size/1024).toFixed(1) + 'KB');
    if (r.duration_seconds) metaParts.push('耗时 ' + fmtDuration(r.duration_seconds));
    var checked = _compareSelection.has(r.name) ? ' checked' : '';
    return '<div class="history-item" onclick="loadReport(\'' + safeName.replace(/'/g, "\\'") + '\')">' +
      '<input type="checkbox" class="compare-check" data-name="' + safeName + '"' + checked +
      ' onclick="event.stopPropagation();toggleCompareSelect(this)" title="选择两份报告进行对比">' +
      '<div class="history-item-body">' +
      '<div class="report-name">' + escHtml(title) + '</div>' +
      '<div class="report-meta">' + escHtml(metaParts.join(' | ')) + '</div>' +
      (args ? '<div class="report-filename">' + safeName + '</div>' : '') +
      '</div>' +
      '<button class="btn-delete-report" onclick="event.stopPropagation();deleteReport(\'' + safeName.replace(/'/g, "\\'") + '\')" title="删除报告">✕</button>' +
      '</div>';
  }).join('');
}

async function deleteReport(filename) {
  if (!confirm('确定删除报告「' + filename + '」？')) return;
  try {
    var headers = {};
    Object.assign(headers, getAuthHeaders());
    var res = await fetch('/api/reports/' + encodeURIComponent(filename), {
      method: 'DELETE', headers: headers
    });
    if (res.ok) {
      _historyData = _historyData.filter(function(r) { return r.name !== filename; });
      _compareSelection.delete(filename);
      renderHistory(_historyData.filter(function(r) {
        var q = document.getElementById('historySearch').value.toLowerCase();
        var hay = ((r.name || '') + ' ' + (r.arguments || '') + ' ' + (r.skill_name || '')).toLowerCase();
        return hay.indexOf(q) >= 0;
      }));
      updateCompareBtn();
      showToast('已删除', 'success');
    } else {
      showToast('删除失败', 'error');
    }
  } catch (e) {
    showToast('删除失败: ' + e.message, 'error');
  }
}

// ==================== Report Compare ====================
function toggleCompareSelect(checkbox) {
  var name = checkbox.dataset.name;
  if (checkbox.checked) {
    if (_compareSelection.size >= 2) {
      checkbox.checked = false;
      showToast('最多选择两份报告进行对比', 'warning');
      return;
    }
    _compareSelection.add(name);
  } else {
    _compareSelection.delete(name);
  }
  updateCompareBtn();
}

function updateCompareBtn() {
  var btn = document.getElementById('btn-compare');
  btn.disabled = _compareSelection.size !== 2;
  btn.textContent = _compareSelection.size === 2 ? '对比所选' :
    '对比所选 (' + _compareSelection.size + '/2)';
}

async function compareSelected() {
  if (_compareSelection.size !== 2) return;
  var names = Array.from(_compareSelection);
  try {
    var headers = {};
    Object.assign(headers, getAuthHeaders());
    var results = await Promise.all(names.map(function(n) {
      return fetch('/api/reports/' + encodeURIComponent(n), { headers: headers })
        .then(function(r) { return r.json(); });
    }));
    if (!results[0].content || !results[1].content) {
      showToast('报告加载失败', 'error');
      return;
    }
    document.getElementById('history-area').style.display = 'none';
    document.getElementById('compare-area').style.display = 'flex';
    document.getElementById('compare-title').textContent = names[0] + ' ⇄ ' + names[1];
    document.getElementById('compare-left').innerHTML =
      '<h3 class="compare-pane-title">' + escHtml(names[0]) + '</h3>' +
      DOMPurify.sanitize(marked.parse(results[0].content));
    document.getElementById('compare-right').innerHTML =
      '<h3 class="compare-pane-title">' + escHtml(names[1]) + '</h3>' +
      DOMPurify.sanitize(marked.parse(results[1].content));
  } catch (e) {
    showToast('对比加载失败: ' + e.message, 'error');
  }
}

function closeCompare() {
  document.getElementById('compare-area').style.display = 'none';
  document.getElementById('history-area').style.display = 'block';
}

async function loadReport(filename) {
  // Block if no model configured
  var _cfg = _loadLlmConfig();
  var _ok = !!(_cfg && (_cfg.model || _cfg.api_key || _cfg.base_url || (_cfg.agent_models && Object.keys(_cfg.agent_models).length)));
  if (!_ok) { showToast('⚠ 请先在模型设置中配置模型', 'error'); return; }
  try {
    var headers = {};
    Object.assign(headers, getAuthHeaders());
    var res = await fetch('/api/reports/' + encodeURIComponent(filename), { headers: headers });
    var data = await res.json();
    if (data.content) {
      currentReport = data.content;
      document.getElementById('history-area').style.display = 'none';
      document.getElementById('result-area').style.display = 'block';
      document.getElementById('restore-banner').style.display = 'none';
      renderReport(data.content);
      buildToc();
      // Show stored run metadata if available
      var metaEl = document.getElementById('report-meta');
      if (data.meta && (data.meta.duration_seconds || (data.meta.tokens && data.meta.tokens.total_tokens))) {
        var parts = [];
        if (data.meta.arguments) parts.push('目标：' + data.meta.arguments);
        if (data.meta.duration_seconds) parts.push('耗时 ' + fmtDuration(data.meta.duration_seconds));
        var tk = fmtTokens(data.meta.tokens);
        if (tk) parts.push('消耗 ' + tk);
        metaEl.textContent = parts.join(' · ');
        metaEl.style.display = 'block';
      } else {
        metaEl.style.display = 'none';
      }
      try { sessionStorage.setItem('ai_berkshire_report', data.content); } catch(e) {}
    }
  } catch (e) {
    showToast('加载报告失败', 'error');
  }
}

// ==================== URL Pre-fill ====================
// ?skill=industry-research&arguments=商业航天 → pre-fill skill + argument
// ?company=宁德时代 → pre-fill argument field only
function prefillFromURL() {
  var params = new URLSearchParams(window.location.search);
  var skill = params.get('skill') || '';
  var args = params.get('arguments') || params.get('company') || '';

  if (!skill && !args) return false;

  if (skill) {
    var found = allSkills.find(function(s) { return s.name === skill; });
    if (found) {
      selectSkill(skill);
      if (args) document.getElementById('arg-field').value = args;
      if (window.history && window.history.replaceState) {
        window.history.replaceState({}, '', window.location.pathname);
      }
      if (args && params.get('auto') !== '0' && params.get('noauto') !== '1') {
        setTimeout(function() { startResearch(); }, 600);
      }
      return true;
    }
  }

  if (args) {
    document.getElementById('arg-field').value = args;
    if (window.history && window.history.replaceState) {
      window.history.replaceState({}, '', window.location.pathname);
    }
    return true;
  }

  return false;
}

// ==================== Save on unload ====================
window.addEventListener('beforeunload', function() {
  if (currentReport) {
    try {
      sessionStorage.setItem('ai_berkshire_report', currentReport);
    } catch(e) {}
  }
  if (ws) { ws.close(); }
});
